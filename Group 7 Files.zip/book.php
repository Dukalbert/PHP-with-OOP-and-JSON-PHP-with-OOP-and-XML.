class Book {
  public $title;
  public $author;
  public $year;

  public function __construct($title, $author, $year) {
    $this->title = $title;
    $this->author = $author;
    $this->year = $year;
  }

  public function toXML() {
    $xml = new SimpleXMLElement('<book></book>');
    $xml->addChild('title', $this->title);
    $xml->addChild('author', $this->author);
    $xml->addChild('year', $this->year);

    return $xml->asXML();
  }
}

$book = new Book("The Great Gatsby", "F. Scott Fitzgerald", 1925);
$xmlData = $book->toXML();

echo $xmlData;
