class User {
  public $name;
  public $email;
  public $age;

  public function __construct($name, $email, $age) {
    $this->name = $name;
    $this->email = $email;
    $this->age = $age;
  }

  public function toJSON() {
    return json_encode($this);
  }
}

$user = new User("John Doe", "john@example.com", 25);
$jsonData = $user->toJSON();

echo $jsonData;
